// Service worker for QuikApply Chrome extension
chrome.runtime.onInstalled.addListener(() => {
  console.log("QuikApply extension installed successfully.");
  
  // Initialize default settings if needed
  chrome.storage.sync.get(['name', 'email', 'resume'], (result) => {
    if (!result.name && !result.email && !result.resume) {
      console.log("First time installation - user needs to set up profile");
    }
  });
});

// Handle messages from content script
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === 'openPopup') {
    // This would typically open the extension popup, but popup can't be programmatically opened
    // Instead, we'll just log for debugging
    console.log('Popup open requested from content script');
  }
  
  sendResponse({success: true});
});

// Handle extension icon click
chrome.action.onClicked.addListener((tab) => {
  // The popup will open automatically when the action icon is clicked
  console.log('Extension icon clicked on tab:', tab.url);
});
