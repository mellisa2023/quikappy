// QuikApply content script - detects application opportunities and handles outreach

(function() {
  'use strict';
  
  // Configuration
  const CONFIG = {
    keywords: [
      'apply', 'apply now', 'join', 'join us', 'join our team', 
      'partner', 'contact', 'contact us', 'get in touch', 
      'careers', 'jobs', 'opportunities', 'hiring', 'work with us',
      'submit application', 'send resume', 'collaborate'
    ],
    selectors: 'a, button, [role="button"], input[type="submit"]',
    highlightClass: 'quikapply-highlighted',
    borderStyle: '2px dashed #ff4444'
  };
  
  let userProfile = null;
  let highlightedElements = [];
  
  // Initialize when DOM is ready
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', initialize);
  } else {
    initialize();
  }
  
  function initialize() {
    loadUserProfile();
    highlightOpportunities();
    setupMessageListener();
    
    // Re-scan periodically for dynamically loaded content
    setInterval(highlightOpportunities, 2000);
  }
  
  function loadUserProfile() {
    chrome.storage.sync.get(['name', 'email', 'resume'], (result) => {
      userProfile = result;
    });
  }
  
  function setupMessageListener() {
    chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
      if (request.action === 'profileUpdated') {
        userProfile = request.profile;
        sendResponse({success: true});
      }
    });
  }
  
  function highlightOpportunities() {
    // Remove existing highlights
    highlightedElements.forEach(el => {
      el.style.border = '';
      el.classList.remove(CONFIG.highlightClass);
      el.removeEventListener('click', handleOpportunityClick);
    });
    highlightedElements = [];
    
    // Find and highlight new opportunities
    const elements = document.querySelectorAll(CONFIG.selectors);
    
    elements.forEach(element => {
      const text = element.textContent || element.value || element.getAttribute('aria-label') || '';
      const href = element.href || '';
      const combinedText = (text + ' ' + href).toLowerCase();
      
      // Check if element contains opportunity keywords
      const isOpportunity = CONFIG.keywords.some(keyword => 
        combinedText.includes(keyword.toLowerCase())
      );
      
      if (isOpportunity && !element.classList.contains(CONFIG.highlightClass)) {
        highlightElement(element);
      }
    });
  }
  
  function highlightElement(element) {
    // Add visual highlight
    element.style.border = CONFIG.borderStyle;
    element.classList.add(CONFIG.highlightClass);
    element.style.cursor = 'pointer';
    
    // Add click handler
    element.addEventListener('click', handleOpportunityClick);
    
    // Track highlighted elements
    highlightedElements.push(element);
    
    // Add tooltip
    element.title = 'QuikApply: Click to generate personalized outreach email';
  }
  
  function handleOpportunityClick(event) {
    event.preventDefault();
    event.stopPropagation();
    
    // Check if user profile is set up
    if (!userProfile || !userProfile.name || !userProfile.email || !userProfile.resume) {
      alert('Please set up your QuikApply profile first by clicking the extension icon.');
      return;
    }
    
    generateOutreachEmail(event.target);
  }
  
  function generateOutreachEmail(element) {
    const pageTitle = document.title;
    const currentUrl = window.location.href;
    const companyName = extractCompanyName();
    
    // Generate email content
    const subject = generateSubject(pageTitle, companyName);
    const body = generateEmailBody(pageTitle, companyName, currentUrl);
    
    // Show preview and get user confirmation
    const userConfirmed = confirm(
      `QuikApply - Preview your outreach email:\n\n` +
      `Subject: ${subject}\n\n` +
      `${body}\n\n` +
      `Click OK to open your email client, or Cancel to abort.`
    );
    
    if (userConfirmed) {
      openEmailClient(subject, body);
    }
  }
  
  function extractCompanyName() {
    // Try to extract company name from various sources
    const hostname = window.location.hostname;
    const domain = hostname.replace('www.', '').split('.')[0];
    
    // Check for company name in page title or meta tags
    const titleCompany = document.title.split(' - ')[0] || document.title.split(' | ')[0];
    const metaCompany = document.querySelector('meta[property="og:site_name"]')?.content;
    
    return metaCompany || titleCompany || capitalizeFirst(domain);
  }
  
  function capitalizeFirst(str) {
    return str.charAt(0).toUpperCase() + str.slice(1);
  }
  
  function generateSubject(pageTitle, companyName) {
    const templates = [
      `Partnership Opportunity - ${userProfile.name}`,
      `Collaboration Inquiry - ${userProfile.name}`,
      `Professional Connection Request - ${userProfile.name}`,
      `Application Inquiry - ${userProfile.name}`
    ];
    
    // Choose template based on page content
    if (pageTitle.toLowerCase().includes('career') || pageTitle.toLowerCase().includes('job')) {
      return `Application: ${pageTitle} - ${userProfile.name}`;
    } else if (pageTitle.toLowerCase().includes('partner')) {
      return templates[0];
    } else {
      return templates[1];
    }
  }
  
  function generateEmailBody(pageTitle, companyName, currentUrl) {
    const body = `Hi there,

I hope this message finds you well. I'm ${userProfile.name}, and I came across your ${pageTitle.toLowerCase().includes('career') || pageTitle.toLowerCase().includes('job') ? 'job posting' : 'opportunity'} on ${companyName} and I'm very interested in connecting.

Here's a brief overview of my background:
${userProfile.resume}

I believe my experience and skills would be a great fit for your team, and I'd love to discuss how I can contribute to ${companyName}'s success.

You can reach me directly at ${userProfile.email}. I'd appreciate the opportunity to learn more about this role and share how I can add value to your organization.

Thank you for your time and consideration.

Best regards,
${userProfile.name}

---
Reference: ${currentUrl}
Sent via QuikApply Chrome Extension`;

    return body;
  }
  
  function openEmailClient(subject, body) {
    const mailtoUrl = `mailto:?subject=${encodeURIComponent(subject)}&body=${encodeURIComponent(body)}`;
    
    // Try to open in current tab first, fallback to new window
    try {
      window.open(mailtoUrl, '_blank');
    } catch (e) {
      window.location.href = mailtoUrl;
    }
  }
  
})();
