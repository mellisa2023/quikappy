// QuikApply popup functionality

// Load saved profile data when popup opens
document.addEventListener('DOMContentLoaded', () => {
  loadProfile();
  setupEventListeners();
});

function loadProfile() {
  chrome.storage.sync.get(['name', 'email', 'resume'], (result) => {
    if (result.name) document.getElementById('name').value = result.name;
    if (result.email) document.getElementById('email').value = result.email;
    if (result.resume) document.getElementById('resume').value = result.resume;
    
    // Show status if profile is loaded
    if (result.name || result.email || result.resume) {
      showStatus('Profile loaded successfully', 'success');
    }
  });
}

function setupEventListeners() {
  // Save profile button
  document.getElementById('save').addEventListener('click', saveProfile);
  
  // Clear data button
  document.getElementById('clear').addEventListener('click', clearProfile);
  
  // Auto-save on input change (debounced)
  let saveTimeout;
  ['name', 'email', 'resume'].forEach(id => {
    document.getElementById(id).addEventListener('input', () => {
      clearTimeout(saveTimeout);
      saveTimeout = setTimeout(saveProfile, 1000); // Auto-save after 1 second of no typing
    });
  });
}

function saveProfile() {
  const name = document.getElementById('name').value.trim();
  const email = document.getElementById('email').value.trim();
  const resume = document.getElementById('resume').value.trim();
  
  // Basic validation
  if (!name || !email || !resume) {
    showStatus('Please fill in all fields to save your profile', 'error');
    return;
  }
  
  // Email validation
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  if (!emailRegex.test(email)) {
    showStatus('Please enter a valid email address', 'error');
    return;
  }
  
  // Save to Chrome storage
  chrome.storage.sync.set({ name, email, resume }, () => {
    if (chrome.runtime.lastError) {
      showStatus('Error saving profile: ' + chrome.runtime.lastError.message, 'error');
    } else {
      showStatus('Profile saved successfully!', 'success');
      
      // Update content scripts on all tabs
      chrome.tabs.query({}, (tabs) => {
        tabs.forEach(tab => {
          chrome.tabs.sendMessage(tab.id, {
            action: 'profileUpdated',
            profile: { name, email, resume }
          }).catch(() => {
            // Ignore errors for tabs that don't have content script
          });
        });
      });
    }
  });
}

function clearProfile() {
  if (confirm('Are you sure you want to clear all profile data? This action cannot be undone.')) {
    chrome.storage.sync.clear(() => {
      if (chrome.runtime.lastError) {
        showStatus('Error clearing profile: ' + chrome.runtime.lastError.message, 'error');
      } else {
        document.getElementById('name').value = '';
        document.getElementById('email').value = '';
        document.getElementById('resume').value = '';
        showStatus('Profile cleared successfully', 'success');
      }
    });
  }
}

function showStatus(message, type) {
  const statusElement = document.getElementById('status-message');
  statusElement.textContent = message;
  statusElement.className = `status-message ${type}`;
  
  // Auto-hide success messages after 3 seconds
  if (type === 'success') {
    setTimeout(() => {
      statusElement.textContent = '';
      statusElement.className = 'status-message';
    }, 3000);
  }
}
